import { Component, OnInit } from '@angular/core';
import { TwitterserviceService } from '../twitterservice.service';

@Component({
  selector: 'app-tweet',
  templateUrl: './tweet.component.html',
  styleUrls: ['./tweet.component.css']
})
export class TweetComponent implements OnInit {
  searchText = 'Kidspot';
  tweets = {};
  tweetData = [];
  loading = false;
  constructor(private twitterService: TwitterserviceService) {

  }

  ngOnInit() {
    this.getTweets();
  }
  /**
   * 
   * function to get tweets
   */
  getTweets(): void {

    let hashTags = [];
    let userMentions = [];
    this.tweetData = [];
    if (this.searchText) {
      this.loading = true;
      this.twitterService.getTweets(this.searchText)
        .subscribe(
          tweets => {
            this.loading = false;
            this.tweets = tweets;
            this.tweets['statuses'].forEach(tweet => {
              hashTags = [];
              userMentions = [];
              tweet['entities']['hashtags'].forEach(hashTag => {
                hashTags.push(hashTag.text);
              });
              tweet['entities']['user_mentions'].forEach(userMention => {
                userMentions.push(userMention.name);
              });
              const data = {
                hashTags: hashTags.join(),
                userMentions: userMentions.join()
              };

              this.tweetData.push(data);

            });


          })
    }

  }

}
