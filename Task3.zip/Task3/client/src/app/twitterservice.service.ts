import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { map } from 'rxjs/operators';
import { Observable } from '../../node_modules/rxjs/Observable';

@Injectable()
export class TwitterserviceService {
  api_url = 'http://localhost:7600';
  constructor(private http: HttpClient) { }

  getTweets(searchText) {
    return this.http.get<any[]>('http://localhost:7600/get-tweets/?query=' + searchText)
    .pipe(map(data => data));
  }

}
