let search = require('../search');

//Require the dev-dependencies
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../app');
let should = chai.should();
chai.use(chaiHttp);

describe('/GET search', () => {
    it('it should GET all the tweets', (done) => {
        chai.request(server)
            .get('/get-tweets?query=kidspot')
            .end((err, res) => {
                res.body.should.be.a('Object');
                res.body.should.have.property('statuses');
                done();
            });
    });
});