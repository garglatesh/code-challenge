var Twit = require('twit');
var config = require('./config')
var T = new Twit(config);
const url = require('url');
/**
 * 
 * get tweets from the twitter
 */
search = {
  getTweets: function (req, res) {
    var params = {
      q: req.query.query,
      count: 100
    }
    T.get('search/tweets', params, function (err, data, response) {
      if (err) {
        return err;
      } else {
        return res.json(data);
      }
    })
  }
}

module.exports = search;
