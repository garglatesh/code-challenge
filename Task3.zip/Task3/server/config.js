module.exports = {
    consumer_key:         '661kt091WFeh8uvjzRgZQlHZ7',
     consumer_secret:      'w4GnZGnCUe2fwrOAnWrT4xZC05STUMPmrBWOiEw8X0VgPFGydO',
     access_token:         '3256437367-n85tFKecceqb2VSjrl1RHm2whUwcRudF4R36MBO',
     access_token_secret:  'b9CXnRYBu2ojMRyxQTwr1lE1gdy6XPVyFxiRRUqQfscSv'
   }
   