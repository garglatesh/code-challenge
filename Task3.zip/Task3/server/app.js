const express = require('express');
const app = express();
var search = require('./search');
app.use(require('cors')());
app.use(require('body-parser').json());
app.get('/get-tweets', search.getTweets);
let port = 7600;
app.listen(port);
console.log("Listening on port " + port);
module.exports = app; // for testing
