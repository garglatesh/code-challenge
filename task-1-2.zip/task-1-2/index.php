<?php

require_once "Card.php";
require_once "CardChecker.php";

echo 'Question 1:';
$card = new Card();
$output =  $card->getCards(5);

echo implode(',',$output)."<br/>";

echo 'Question 2:';
$output= ["jc", "10c", "6c", "8c", "7c"];
$result = (new CardChecker())->checker($output);
if($result){
  $values = implode(',',$result);
  if($values == '1,1'){
      echo "Cards are Staright Flush";
  }else if($values == '1,0'){
      echo "Cards are Staright";
  }else{
      echo "Neither Staright nor Staright Flush ";
  }
}
?>
