<?php
/**
 * Class Card
 **/

class Card
{
    /** @var array */
    const RANKS = [
        'a',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        'j',
        'q',
        'k'
    ];

    /** @var array */
    const SUITS = [
        'c',
        'd',
        'h',
        's'
    ];

    /**
     * @param int $number
     * @return array
     */
    public function getCards(int $number)
    {
        $cards = [];

        while ($number > 0) {
            $card = self::RANKS[array_rand(self::RANKS)] . self::SUITS[array_rand(self::SUITS)];
            if (false === in_array($card, $cards)) {
                $cards[] = $card;
                $number--;
            }
        }

        return $cards;
    }
}

