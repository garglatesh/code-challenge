<?php
/**
 * Class CardChecker
*/
class CardChecker
{

    public function checker($d) {
        $b = $f = 0;
        $m = ['a'=>1,1=>10,'j'=>11,'q'=>12,'k'=>13];
        foreach ($d as $a) {
            $p = substr($a,-1);
            $b |= 1<<(($m[$a[0]])??$a[0]);
            $f = ($f===0||$f===$p) ? $p : 1;
        }
        $b = ($b << 3) | ($b >> 10);
        foreach (range(0,13) as $i) {
            if ((($b >> $i) & 31) == 31){
                return [true, $f!=1];
            }
        }
        return [false, false];
    }



}
