<?php
use PHPUnit\Framework\TestCase;

class CardTest extends TestCase
{
    /**
     * check array of the length should be 5
     */

    public function testArrayLength()
    {
        $array = ["jc", "10c", "6c", "8c", "7c"];
        $this->assertEquals(sizeof($array),5);
    }

    /**
     *
     *
     */
    public function testCardSuits()
    {
        $array = ["8d", "8p"];
        $suits = [
            'c',
            'd',
            'h',
            's'
        ];
        foreach($array as $a){
            $p = substr($a, -1);
            $this->assertNotContains($p, $suits, "array contains value as value");

        }
    }
}
?>