<?php
require_once "CardChecker.php";
use PHPUnit\Framework\TestCase;


class CardCheckerTest extends TestCase
{
    /**
     * check function should return in boolean
     */

    public function testReturnValue() {
        $array = ["jc", "10c", "6c", "8c", "7c"];
        $result = (new CardChecker())->checker($array);
        $this->assertIsBool($result[0]);
     }
}
?>